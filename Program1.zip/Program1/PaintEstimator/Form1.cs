﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PaintEstimator
{
    public partial class PaintEstimator : Form
    {
        public PaintEstimator()
        {
            InitializeComponent();
        }

        private void CalculateBtn_Click(object sender, EventArgs e)
        {
            const int DOORSIZE = 20; //contstant door size
            const int WINDOWSIZE = 15; // constant window size
            const int PAINT = 385; //amount of square feet coved by one gallon of paint
            double wallHeight; // height of walls
            double wallLength; // length of walls
            int windows; // number of windows
            int doors; // number of doors
            int coats; // number of coats the user wants
            double parimeter; // total parimeter of the walls
            int doorTotal; // total space taken up by doors
            int windowTotal; // total space taken up by windows
            double totalWall; // total parimeter adjusted for walls and windows
            double gallonsNeeded; // gallons of paint needed
            int gallonsToBuy; // number of gallons that the user should buy

            //aquiring necessary input from user
            wallHeight = double.Parse(wallHeightTxt.Text);
            wallLength = double.Parse(wallLengthTxt.Text);
            doors = int.Parse(doorNumTxt.Text);
            windows = int.Parse(windowNumTxt.Text);
            coats = int.Parse(paintCoatTxt.Text);

            //calculations
            parimeter = wallHeight * wallLength;
            doorTotal = DOORSIZE * doors;
            windowTotal = WINDOWSIZE * windows;
            totalWall = parimeter - (doorTotal + windowTotal);
            gallonsNeeded = (totalWall * coats) / PAINT;
            gallonsToBuy = (int)Math.Ceiling(gallonsNeeded);

            //output
            minimumOutput.Text = $"{gallonsNeeded:F1}";
            totalGallonOutput.Text = $"{gallonsToBuy}";






        }
    }
}
