﻿namespace PaintEstimator
{
    partial class PaintEstimator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wallLengthLbl = new System.Windows.Forms.Label();
            this.wallHeightLbl = new System.Windows.Forms.Label();
            this.doorNumLbl = new System.Windows.Forms.Label();
            this.windowNumLbl = new System.Windows.Forms.Label();
            this.paintCoatLbl = new System.Windows.Forms.Label();
            this.wallLengthTxt = new System.Windows.Forms.TextBox();
            this.wallHeightTxt = new System.Windows.Forms.TextBox();
            this.doorNumTxt = new System.Windows.Forms.TextBox();
            this.windowNumTxt = new System.Windows.Forms.TextBox();
            this.paintCoatTxt = new System.Windows.Forms.TextBox();
            this.CalculateBtn = new System.Windows.Forms.Button();
            this.minimumGallonLbl = new System.Windows.Forms.Label();
            this.minimumOutput = new System.Windows.Forms.Label();
            this.totalGallonOutput = new System.Windows.Forms.Label();
            this.totalGallonLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // wallLengthLbl
            // 
            this.wallLengthLbl.AutoSize = true;
            this.wallLengthLbl.Location = new System.Drawing.Point(12, 9);
            this.wallLengthLbl.Name = "wallLengthLbl";
            this.wallLengthLbl.Size = new System.Drawing.Size(241, 17);
            this.wallLengthLbl.TabIndex = 0;
            this.wallLengthLbl.Text = "Enter total length of all walls (in feet):";
            // 
            // wallHeightLbl
            // 
            this.wallHeightLbl.AutoSize = true;
            this.wallHeightLbl.Location = new System.Drawing.Point(12, 49);
            this.wallHeightLbl.Name = "wallHeightLbl";
            this.wallHeightLbl.Size = new System.Drawing.Size(192, 17);
            this.wallHeightLbl.TabIndex = 1;
            this.wallHeightLbl.Text = "Enter height of walls (in feet):";
            // 
            // doorNumLbl
            // 
            this.doorNumLbl.AutoSize = true;
            this.doorNumLbl.Location = new System.Drawing.Point(12, 87);
            this.doorNumLbl.Name = "doorNumLbl";
            this.doorNumLbl.Size = new System.Drawing.Size(154, 17);
            this.doorNumLbl.TabIndex = 2;
            this.doorNumLbl.Text = "Enter number of doors:";
            // 
            // windowNumLbl
            // 
            this.windowNumLbl.AutoSize = true;
            this.windowNumLbl.Location = new System.Drawing.Point(12, 127);
            this.windowNumLbl.Name = "windowNumLbl";
            this.windowNumLbl.Size = new System.Drawing.Size(170, 17);
            this.windowNumLbl.TabIndex = 3;
            this.windowNumLbl.Text = "Enter number of windows:";
            // 
            // paintCoatLbl
            // 
            this.paintCoatLbl.AutoSize = true;
            this.paintCoatLbl.Location = new System.Drawing.Point(12, 164);
            this.paintCoatLbl.Name = "paintCoatLbl";
            this.paintCoatLbl.Size = new System.Drawing.Size(234, 17);
            this.paintCoatLbl.TabIndex = 4;
            this.paintCoatLbl.Text = "Enter the number of coats of paints:";
            // 
            // wallLengthTxt
            // 
            this.wallLengthTxt.Location = new System.Drawing.Point(281, 9);
            this.wallLengthTxt.Name = "wallLengthTxt";
            this.wallLengthTxt.Size = new System.Drawing.Size(100, 22);
            this.wallLengthTxt.TabIndex = 5;
            // 
            // wallHeightTxt
            // 
            this.wallHeightTxt.Location = new System.Drawing.Point(281, 49);
            this.wallHeightTxt.Name = "wallHeightTxt";
            this.wallHeightTxt.Size = new System.Drawing.Size(100, 22);
            this.wallHeightTxt.TabIndex = 6;
            // 
            // doorNumTxt
            // 
            this.doorNumTxt.Location = new System.Drawing.Point(281, 87);
            this.doorNumTxt.Name = "doorNumTxt";
            this.doorNumTxt.Size = new System.Drawing.Size(100, 22);
            this.doorNumTxt.TabIndex = 7;
            // 
            // windowNumTxt
            // 
            this.windowNumTxt.Location = new System.Drawing.Point(281, 127);
            this.windowNumTxt.Name = "windowNumTxt";
            this.windowNumTxt.Size = new System.Drawing.Size(100, 22);
            this.windowNumTxt.TabIndex = 8;
            // 
            // paintCoatTxt
            // 
            this.paintCoatTxt.Location = new System.Drawing.Point(281, 164);
            this.paintCoatTxt.Name = "paintCoatTxt";
            this.paintCoatTxt.Size = new System.Drawing.Size(100, 22);
            this.paintCoatTxt.TabIndex = 9;
            // 
            // CalculateBtn
            // 
            this.CalculateBtn.Location = new System.Drawing.Point(281, 215);
            this.CalculateBtn.Name = "CalculateBtn";
            this.CalculateBtn.Size = new System.Drawing.Size(100, 23);
            this.CalculateBtn.TabIndex = 10;
            this.CalculateBtn.Text = "Calculate";
            this.CalculateBtn.UseVisualStyleBackColor = true;
            this.CalculateBtn.Click += new System.EventHandler(this.CalculateBtn_Click);
            // 
            // minimumGallonLbl
            // 
            this.minimumGallonLbl.AutoSize = true;
            this.minimumGallonLbl.Location = new System.Drawing.Point(12, 295);
            this.minimumGallonLbl.Name = "minimumGallonLbl";
            this.minimumGallonLbl.Size = new System.Drawing.Size(236, 17);
            this.minimumGallonLbl.TabIndex = 11;
            this.minimumGallonLbl.Text = "Minimum number of gallons needed:";
            // 
            // minimumOutput
            // 
            this.minimumOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.minimumOutput.Location = new System.Drawing.Point(281, 295);
            this.minimumOutput.Name = "minimumOutput";
            this.minimumOutput.Size = new System.Drawing.Size(100, 23);
            this.minimumOutput.TabIndex = 12;
            // 
            // totalGallonOutput
            // 
            this.totalGallonOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalGallonOutput.Location = new System.Drawing.Point(281, 338);
            this.totalGallonOutput.Name = "totalGallonOutput";
            this.totalGallonOutput.Size = new System.Drawing.Size(100, 23);
            this.totalGallonOutput.TabIndex = 13;
            // 
            // totalGallonLbl
            // 
            this.totalGallonLbl.AutoSize = true;
            this.totalGallonLbl.Location = new System.Drawing.Point(12, 338);
            this.totalGallonLbl.Name = "totalGallonLbl";
            this.totalGallonLbl.Size = new System.Drawing.Size(213, 17);
            this.totalGallonLbl.TabIndex = 14;
            this.totalGallonLbl.Text = "Total number of gallons needed:";
            // 
            // PaintEstimator
            // 
            this.AcceptButton = this.CalculateBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.totalGallonLbl);
            this.Controls.Add(this.totalGallonOutput);
            this.Controls.Add(this.minimumOutput);
            this.Controls.Add(this.minimumGallonLbl);
            this.Controls.Add(this.CalculateBtn);
            this.Controls.Add(this.paintCoatTxt);
            this.Controls.Add(this.windowNumTxt);
            this.Controls.Add(this.doorNumTxt);
            this.Controls.Add(this.wallHeightTxt);
            this.Controls.Add(this.wallLengthTxt);
            this.Controls.Add(this.paintCoatLbl);
            this.Controls.Add(this.windowNumLbl);
            this.Controls.Add(this.doorNumLbl);
            this.Controls.Add(this.wallHeightLbl);
            this.Controls.Add(this.wallLengthLbl);
            this.Name = "PaintEstimator";
            this.Text = "Paint Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wallLengthLbl;
        private System.Windows.Forms.Label wallHeightLbl;
        private System.Windows.Forms.Label doorNumLbl;
        private System.Windows.Forms.Label windowNumLbl;
        private System.Windows.Forms.Label paintCoatLbl;
        private System.Windows.Forms.TextBox wallLengthTxt;
        private System.Windows.Forms.TextBox wallHeightTxt;
        private System.Windows.Forms.TextBox doorNumTxt;
        private System.Windows.Forms.TextBox windowNumTxt;
        private System.Windows.Forms.TextBox paintCoatTxt;
        private System.Windows.Forms.Button CalculateBtn;
        private System.Windows.Forms.Label minimumGallonLbl;
        private System.Windows.Forms.Label minimumOutput;
        private System.Windows.Forms.Label totalGallonOutput;
        private System.Windows.Forms.Label totalGallonLbl;
    }
}

